import httpx
import sys

def verify_recursive_enhancements():
    print("Testing Recursive-Size Educational Enhancements API response...")
    client = httpx.Client(base_url="http://127.0.0.1:8000")
    
    sample_text = (
        "Paragraph One text goes here. It has multiple words and lines.\n"
        "Line two is here.\n\n"
        "Paragraph Two starts here. Another sentence here! A third sentence to make it longer."
    )
    
    payload = {
        "text": sample_text,
        "chunk_size": 50,
        "chunk_overlap": 10
    }
    
    res = client.post("/chunk/recursive", json=payload)
    assert res.status_code == 200, f"API failed with status {res.status_code}"
    
    data = res.json()
    chunks = data["chunks"]
    metrics = data["metrics"]
    comparison = data["comparison"]
    
    print(f"Total chunks generated: {len(chunks)}")
    assert len(chunks) > 0, "Should generate chunks"
    
    # Verify first chunk keys
    first_chunk = chunks[0]
    required_chunk_keys = [
        "start_char", "end_char", "word_broken", "sentence_broken", 
        "split_level", "separator", "reason", "decision_path", 
        "paragraph_index", "line_index", "quality", "quality_reason", "stats"
    ]
    for key in required_chunk_keys:
        assert key in first_chunk, f"Missing required chunk key: {key}"
        print(f" [PASS] Found chunk key: {key} (value: {first_chunk[key]})")
        
    # Verify stats keys
    stats = first_chunk["stats"]
    required_stats_keys = ["chars", "words", "sentences", "paragraphs", "tokens"]
    for key in required_stats_keys:
        assert key in stats, f"Missing stats key: {key}"
        print(f" [PASS] Found stats key: {key} (value: {stats[key]})")
        
    # Verify metrics keys
    required_metrics_keys = [
        "total_chunks", "avg_size", "processing_time_ms", 
        "paragraph_preservation", "line_preservation", 
        "word_breaks", "character_breaks", "separator_counts"
    ]
    for key in required_metrics_keys:
        assert key in metrics, f"Missing metrics key: {key}"
        print(f" [PASS] Found metrics key: {key} (value: {metrics[key]})")
        
    # Verify comparison keys
    assert "fixed" in comparison, "Missing fixed comparison metrics"
    assert "recursive" in comparison, "Missing recursive comparison metrics"
    print(" [PASS] Comparison keys verified!")
    
    print("\nALL RECURSIVE-SIZE CHARACTER CHUNKING ENHANCEMENTS VERIFIED SUCCESSFULLY!")

if __name__ == "__main__":
    try:
        verify_recursive_enhancements()
    except AssertionError as e:
        print(f"\n[FAIL] Assertion failed: {str(e)}")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        sys.exit(1)
